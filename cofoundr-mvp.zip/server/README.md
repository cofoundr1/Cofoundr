# CoFoundr API

1) Copy .env.example to .env and fill values
2) npm i
3) npm run dev
